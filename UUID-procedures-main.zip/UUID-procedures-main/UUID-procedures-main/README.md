# UUID-procedures
This is repository for my MCreator plugin called "UUID-procedures"
It adds a UUID related procedure such as "Get UUID of [INSERT ENTITY]"
